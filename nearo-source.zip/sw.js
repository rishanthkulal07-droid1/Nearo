const CACHE="nearo-v15";
const FILES=["./","./index.html","./manifest.webmanifest","./css/styles.css","./js/loader.js","./js/config.js","./js/i18n.js","./js/app.js","./js/admin.js","./js/studio.js","./js/ide.js","./js/start.js","./js/pwa.js","./icons/icon-192.png","./icons/icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting();});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))));self.clients.claim();});
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;
 e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(CACHE).then(x=>x.put(e.request,c));return r;}).catch(()=>caches.match(e.request).then(m=>m||caches.match("./index.html"))));});
