/* Nearo - js/pwa.js : registers the service worker so the app can be installed and work offline. */
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));}
