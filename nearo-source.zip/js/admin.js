/* Nearo - js/admin.js
   ACCOUNTS, SIGN-IN AND ADMIN CONSOLE.
   Load order in index.html: config, i18n, app, admin, studio, start. */
/* ===== ACCOUNTS, SESSIONS AND ADMIN CONSOLE ===== */
const ALPH="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const DEFAULT_ADMIN_CODE="NEAROADMIN2026"; // shown as NEARO-ADMIN-2026; forced to change on first sign-in
const enc=new TextEncoder(),rnd=n=>crypto.getRandomValues(new Uint8Array(n));
const b64=u=>btoa(String.fromCharCode.apply(null,u)),unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const norm=s=>String(s||"").toUpperCase().replace(/[^A-Z0-9]/g,"");
const fmtCode=c=>c.replace(/(.{4})(?=.)/g,"$1-");
const genCode=()=>{const r=rnd(12);let s="";for(let i=0;i<12;i++)s+=ALPH[r[i]%32];return s};
const genPass=()=>{const r=rnd(8);let s="";for(let i=0;i<8;i++)s+=ALPH[r[i]%32];return s};
const newId=p=>p+Date.now().toString(36)+Array.from(rnd(3),x=>x.toString(36)).join("");
async function hashSecret(secret,saltB64){
  const salt=saltB64?unb64(saltB64):rnd(16);let out;
  if(window.crypto&&crypto.subtle){
    const k=await crypto.subtle.importKey("raw",enc.encode(secret),"PBKDF2",false,["deriveBits"]);
    out=new Uint8Array(await crypto.subtle.deriveBits({name:"PBKDF2",hash:"SHA-256",salt,iterations:120000},k,256));
  }else{ // very old browsers / non-HTTPS pages: weaker fallback
    let h1=0xdeadbeef,h2=0x41c6ce57;const s=secret+b64(salt);
    for(let r=0;r<3000;r++)for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);h1=Math.imul(h1^c,2654435761);h2=Math.imul(h2^c,1597334677)}
    out=new Uint8Array(new Uint32Array([h1>>>0,h2>>>0]).buffer);
  }
  return{salt:b64(salt),hash:b64(out)};
}
let ACC=load("nearo.accounts",[]),ADM=load("nearo.admins",[]),SESS=load("nearo.session",null),SID=null,MYID=null;
let admTab="overview",authRole="user",signupMode=false,accQ="",accRole="all",bkSt="all";
const saveACC=()=>store("nearo.accounts",ACC),saveADM=()=>store("nearo.admins",ADM),saveCFG=()=>store("nearo.config",CFG);
const mineC=b=>b.customer&&b.uid===SID;
const meAdm=()=>ADM.find(a=>a.id===SID);
const isSuper=()=>{const a=meAdm();return !!a&&a.level==="super"};
const expired=a=>!!a.expires&&a.expires<Date.now();
const live=a=>a.active&&!expired(a);
const fmtDT=t=>t?new Date(t).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}):"Never";

/* ---------- small dialog helper (confirm / one-time secret / input) ---------- */
function dlgBox(o){
  return new Promise(res=>{
    const d=$("mdlg");let done=false;
    $("mTitle").textContent=o.title||"";$("mMsg").textContent=o.msg||"";
    $("mSecret").hidden=!o.secret;$("mSecret").textContent=o.secret||"";$("mCopy").hidden=!o.secret;
    $("mInWrap").hidden=!o.input;
    if(o.input){$("mInLbl").textContent=o.input.label;$("mIn").type=o.input.type||"text";$("mIn").value=o.input.value||""}
    $("mErr").textContent="";$("mYes").textContent=o.ok||"OK";$("mNo").hidden=o.cancel===false;
    const cleanup=()=>{$("mForm").removeEventListener("submit",yes);$("mNo").removeEventListener("click",no);$("mCopy").removeEventListener("click",copy);d.removeEventListener("cancel",cancelEv)};
    const fin=v=>{if(done)return;done=true;cleanup();if(d.open)d.close();res(v)};
    const yes=e=>{e.preventDefault();if(o.input){const v=$("mIn").value,m=o.input.validate?o.input.validate(v):"";if(m){$("mErr").textContent=m;return}fin(v)}else fin(true)};
    const no=()=>{if(o.cancel!==false)fin(null)};
    const cancelEv=e=>{e.preventDefault();no()};
    const copy=()=>{if(navigator.clipboard)navigator.clipboard.writeText(o.secret).then(()=>toast("Copied"),()=>toast("Select the text and copy it"));else toast("Select the text and copy it")};
    $("mForm").addEventListener("submit",yes);$("mNo").addEventListener("click",no);$("mCopy").addEventListener("click",copy);d.addEventListener("cancel",cancelEv);
    d.showModal();if(o.input)$("mIn").focus();
  });
}

/* ---------- applying the signed-in session to the app ---------- */
function bindSession(){
  role=null;SID=null;MYID=null;myPro=null;proLoc=null;
  if(!SESS)return false;
  if(SESS.kind==="admin"){const a=ADM.find(x=>x.id===SESS.id);if(!a||!live(a))return false;role="admin";SID=a.id;return true}
  const a=ACC.find(x=>x.id===SESS.id);if(!a||a.suspended)return false;
  role=a.role;SID=a.id;
  if(role==="pro"){MYID="p_"+a.id;myPro=load("fixnear.pro."+a.id,null);proLoc=myPro&&myPro.lat!=null?{lat:myPro.lat,lng:myPro.lng}:null}
  else cust=load("fixnear.cust."+a.id,{name:a.name,phone:a.phone});
  return true;
}
const ROLE_LABEL={user:"Customer",pro:"Handyman"};
function showApp(msg){
  const ok=bindSession();
  document.body.classList.toggle("out",!ok);
  if(!ok){
    if(SESS){SESS=null;localStorage.removeItem("nearo.session")}
    setAuth();if(msg)$(authRole==="admin"?"aErr":"lErr").textContent=msg;
    window.scrollTo(0,0);return;
  }
  if(role!=="admin"&&CFG.maintenance){SESS=null;localStorage.removeItem("nearo.session");document.body.classList.add("out");setAuth();$(authRole==="admin"?"aErr":"lErr").textContent="Nearo is under maintenance right now. Please try again soon.";return}
  const acc=role==="admin"?meAdm():ACC.find(x=>x.id===SID);
  $("acctName").textContent=role==="admin"?acc.label:acc.name;
  $("acctRole").textContent=role==="admin"?(acc.level==="super"?"Admin":"Employee"):ROLE_LABEL[role];
  ["uName","pName"].forEach(i=>delete $(i).dataset.filled);
  ["pName","pPhone","pPrice","pAbout"].forEach(i=>$(i).value="");$("pYears").value=3;$("pLocStatus").textContent="";
  if(role==="pro"&&!myPro){$("pName").value=acc.name;$("pPhone").value=digits(acc.phone)}
  uTab="find";pTab="requests";admTab="overview";hot=null;
  const rs=sessionStorage.getItem("nearo.cs");if(rs){sessionStorage.removeItem("nearo.cs");if(role==="admin"&&isSuper()){admTab="studio";csTab=rs}}
  if(!CATEGORIES.includes(cat))cat=CATEGORIES[0];
  render();applyLang();window.scrollTo(0,0);emit("login",role);
  if(role==="admin"&&acc.mustChange)changeOwn(true);
}
function startSession(s){SESS=s;store("nearo.session",s);showApp()}
function logout(){emit("logout",role);SESS=null;localStorage.removeItem("nearo.session");role=null;signupMode=false;showApp()}
$("logoutBtn").onclick=()=>logout();

/* ---------- login / sign-up screen ---------- */
function setAuth(){
  document.querySelectorAll("#rtabs [data-r]").forEach(b=>b.setAttribute("aria-selected",String(b.dataset.r===authRole)));
  const adm=authRole==="admin";
  $("loginForm").hidden=adm||signupMode;$("signupForm").hidden=adm||!signupMode;$("adminForm").hidden=!adm;
  $("authLead").textContent={user:"Sign in to book trusted handymen near you.",pro:"Sign in to receive bookings and manage your jobs.",admin:"Restricted area for Nearo staff and administrators."}[authRole];
  $("sBtn").textContent=authRole==="pro"?"Create handyman account":"Create customer account";
  ["lErr","sErr","aErr"].forEach(i=>$(i).textContent="");
}
$("rtabs").addEventListener("click",e=>{const b=e.target.closest("[data-r]");if(!b)return;authRole=b.dataset.r;signupMode=false;setAuth()});
$("toSignup").onclick=()=>{signupMode=true;setAuth()};
$("toLogin").onclick=()=>{signupMode=false;setAuth()};
document.addEventListener("click",e=>{const b=e.target.closest("[data-showpw]");if(!b)return;const i=$(b.dataset.showpw);i.type=i.type==="password"?"text":"password";b.textContent=i.type==="password"?"Show":"Hide"});
const lockLeft=()=>{const l=load("nearo.lock",{n:0,until:0});return Math.max(0,Math.ceil((l.until-Date.now())/1000))};
const failOnce=()=>{const l=load("nearo.lock",{n:0,until:0});l.n++;if(l.n>=5){l.until=Date.now()+60000;l.n=0}store("nearo.lock",l)};
const okOnce=()=>store("nearo.lock",{n:0,until:0});

$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault();const E=$("lErr");E.textContent="";
  const ph=digits($("lPhone").value),pw=$("lPass").value;
  if(ph.length<10)return void(E.textContent="Enter your 10-digit mobile number.");
  if(!pw)return void(E.textContent="Enter your password.");
  const w=lockLeft();if(w)return void(E.textContent=`Too many wrong attempts. Try again in ${w} seconds.`);
  if(CFG.maintenance)return void(E.textContent="Nearo is under maintenance right now. Please try again soon.");
  const a=ACC.find(x=>x.role===authRole&&x.phone===ph);
  if(!a){const o=ACC.find(x=>x.phone===ph);
    E.textContent=o?`This number is registered as a ${o.role==="pro"?"handyman":"customer"}. Open the ${o.role==="pro"?"Handyman":"Customer"} tab to sign in.`:"No account found for this number. Create one below.";return}
  const h=await hashSecret(pw,a.salt);
  if(h.hash!==a.hash){failOnce();E.textContent="Wrong password. Try again.";return}
  if(a.suspended)return void(E.textContent="This account is suspended. Please contact Nearo support.");
  okOnce();a.lastLogin=Date.now();saveACC();$("lPass").value="";startSession({kind:"acct",id:a.id});
});
$("signupForm").addEventListener("submit",async e=>{
  e.preventDefault();const E=$("sErr");E.textContent="";
  const name=$("sName").value.trim(),ph=digits($("sPhone").value),p1=$("sPass").value,p2=$("sPass2").value;
  const err=name.length<2?"Enter your full name.":ph.length<10?"Enter a 10-digit mobile number.":p1.length<6?"Choose a password with at least 6 characters.":p1!==p2?"The two passwords don’t match.":ACC.some(x=>x.role===authRole&&x.phone===ph)?"An account with this number already exists. Sign in instead.":CFG.maintenance?"Nearo is under maintenance right now. Please try again soon.":"";
  if(err)return void(E.textContent=err);
  const h=await hashSecret(p1),a={id:newId(authRole==="pro"?"h":"c"),role:authRole,name,phone:ph,...h,created:Date.now(),suspended:false,lastLogin:Date.now()};
  // first account of each kind adopts any data saved before logins existed
  if(!ACC.some(x=>x.role===authRole)){
    if(authRole==="pro"){const old=load("fixnear.pro",null);if(old){store("fixnear.pro."+a.id,old);localStorage.removeItem("fixnear.pro");B.forEach(b=>{if(b.proId==="me")b.proId="p_"+a.id});saveB()}}
    else{const old=load("fixnear.cust",null);if(old)store("fixnear.cust."+a.id,old);B.forEach(b=>{if(b.customer&&!b.uid)b.uid=a.id});saveB()}
  }
  ACC.push(a);saveACC();["sName","sPhone","sPass","sPass2"].forEach(i=>$(i).value="");signupMode=false;startSession({kind:"acct",id:a.id});
  toast("Welcome to Nearo, "+name.split(" ")[0]);
});
$("adminForm").addEventListener("submit",async e=>{
  e.preventDefault();const E=$("aErr");E.textContent="";
  const c=norm($("aCode").value);if(!c)return void(E.textContent="Enter your access code.");
  const w=lockLeft();if(w)return void(E.textContent=`Too many wrong attempts. Try again in ${w} seconds.`);
  for(const a of ADM){if(!live(a))continue;const h=await hashSecret(c,a.salt);
    if(h.hash===a.hash){okOnce();a.lastUsed=Date.now();saveADM();$("aCode").value="";startSession({kind:"admin",id:a.id});return}}
  failOnce();E.textContent="That access code is not valid. It may be wrong, revoked or expired.";
});

/* ---------- admin: helpers ---------- */
async function codeTaken(code,exceptId){for(const a of ADM){if(a.id===exceptId)continue;if((await hashSecret(code,a.salt)).hash===a.hash)return true}return false}
const superLeft=exceptId=>ADM.some(a=>a.id!==exceptId&&a.level==="super"&&live(a));
async function changeOwn(forced){
  for(;;){
    const v=await dlgBox({title:forced?"Set your own access code":"Change my access code",msg:forced?"You signed in with the default code. Choose a private code now. Anyone who knows the default code could otherwise enter the admin console.":"Choose a new code. It replaces your current one immediately.",input:{label:"New access code (8+ letters or digits)",type:"text",validate:v=>norm(v).length<8?"Use at least 8 letters or digits.":""},ok:"Save code",cancel:forced?false:true});
    if(v===null)return;
    const c=norm(v);if(await codeTaken(c,SID)){toast("That code is already in use. Pick another.");continue}
    const a=meAdm(),h=await hashSecret(c);Object.assign(a,h,{mustChange:false});saveADM();renderAdmin();
    await dlgBox({title:"Code saved",msg:"Use this code next time you sign in. Keep it private.",secret:fmtCode(c),ok:"Done",cancel:false});return;
  }
}
const bkRow=b=>`<tr><td>${esc(String(b.id).slice(-6))}</td><td>${esc(b.name||"")}</td><td>${esc(b.proName||"")}<div class="meta">${esc(b.trade||"")}</div></td><td><span class="tag ${b.status==="completed"?"ok":b.status==="cancelled"||b.status==="declined"?"bad":"warn"}">${esc(STATUS[b.status]||b.status)}</span></td><td>${money(jobAmount(b))}</td><td>${esc(b.date||"")}</td></tr>`;
const BKHEAD="<tr><th>ID</th><th>Customer</th><th>Handyman</th><th>Status</th><th>Amount</th><th>Date</th></tr>";

/* ---------- admin: tabs ---------- */
const ADM_TABS=[["overview","Overview",0],["codes","Access codes",1],["accounts","Accounts",0],["bookings","Bookings",0],["materials","Material prices",0],["settings","Settings",1],["studio","Code studio",1]];
function renderAdmin(){
  const a=meAdm();if(!a)return;
  $("admWho").textContent=`Signed in as ${a.label} · ${a.level==="super"?"Administrator (full access)":"Employee (day-to-day access)"}`;
  if(!isSuper()&&(admTab==="codes"||admTab==="settings"||admTab==="studio"))admTab="overview";
  const f=({overview:admOverview,codes:admCodes,accounts:admAccounts,bookings:admBookings,materials:admMaterials,settings:admSettings,studio:admStudio})[admTab];if(!f)return;
  $("admBody").innerHTML=f();csAfter();
}
function admOverview(){
  const cu=ACC.filter(a=>a.role==="user").length,pr=ACC.filter(a=>a.role==="pro").length,sus=ACC.filter(a=>a.suspended).length;
  const done=B.filter(b=>b.status==="completed"),gmv=done.reduce((s,b)=>s+jobAmount(b),0);
  const st=[[cu,"Customer accounts"],[pr,"Handyman accounts"],[sus,"Suspended accounts"],[B.length,"Total bookings"],[B.filter(active).length,"Open bookings"],[done.length,"Completed jobs"],[money(gmv),"Value of completed jobs"],[ADM.filter(live).length,"Active access codes"]];
  const warn=ADM.some(a=>a.mustChange&&a.active)?`<div class="warnbox"><b>The default admin code is still active.</b> Open Access codes and replace it with your own.</div>`:"";
  return `${warn}<div class="stats">${st.map(([v,l])=>`<div class="stat"><b>${v}</b><span class="meta">${l}</span></div>`).join("")}</div>
  <h2 style="margin:22px 0 10px">Latest bookings</h2>
  ${B.length?`<div class="tblw"><table class="tbl">${BKHEAD}${B.slice(0,6).map(bkRow).join("")}</table></div>`:`<div class="empty">No bookings yet.</div>`}`;
}
function admCodes(){
  const rows=ADM.map(a=>{const s=!a.active?["Revoked","bad"]:expired(a)?["Expired","warn"]:a.mustChange?["Default: change it","warn"]:["Active","ok"],you=a.id===SID;
    return `<tr><td><b>${esc(a.label)}</b>${you?' <span class="meta">(you)</span>':""}<div class="meta">Created ${esc(fmtDT(a.created))} by ${esc(a.by||"")}</div></td>
    <td>${a.level==="super"?"Admin":"Employee"}</td><td><span class="tag ${s[1]}">${s[0]}</span></td>
    <td>${esc(fmtDT(a.lastUsed))}<div class="meta">Expires: ${a.expires?esc(fmtDT(a.expires)):"never"}</div></td>
    <td><div class="acts">${you?`<button class="btn ghost sm" data-adm="mine">Change my code</button>`:`<button class="btn ghost sm" data-adm="reset" data-id="${a.id}">New code</button>`}
    <button class="btn ghost sm" data-adm="toggle" data-id="${a.id}">${a.active?"Revoke":"Restore"}</button>
    <button class="btn bad sm" data-adm="del" data-id="${a.id}">Delete</button></div></td></tr>`}).join("");
  return `<div class="panel admform" style="margin-bottom:18px"><h2>Give someone access</h2>
    <p class="meta" style="margin:4px 0 0">Create a personal access code for an employee or another admin. The code is shown once. Revoke it any time.</p>
    <form data-form="newcode" novalidate>
    <div class="row2"><div><label for="cdLabel">Name or role</label><input id="cdLabel" name="label" placeholder="e.g. Priya, support desk"></div>
    <div><label for="cdLevel">Access level</label><select id="cdLevel" name="level"><option value="staff">Employee: bookings, accounts, material prices</option><option value="super">Admin: everything, including codes and settings</option></select></div></div>
    <div class="row2"><div><label for="cdExp">Expires</label><select id="cdExp" name="exp"><option value="0">Never</option><option value="1">After 1 day</option><option value="7">After 7 days</option><option value="30">After 30 days</option><option value="90">After 90 days</option></select></div>
    <div><label for="cdCustom">Custom code (optional)</label><input id="cdCustom" name="custom" placeholder="Leave empty to generate one" autocomplete="off"></div></div>
    <button class="btn" type="submit" style="margin-top:14px">Create access code</button></form></div>
  <h2 style="margin:0 0 10px">All access codes</h2>
  <div class="tblw"><table class="tbl"><tr><th>Person</th><th>Level</th><th>Status</th><th>Last used</th><th>Actions</th></tr>${rows}</table></div>
  <p class="meta" style="margin-top:10px">Codes are stored scrambled (hashed), so nobody can read them back, not even admins. Use “New code” if one is lost.</p>`;
}
function accTable(){
  const q=accQ.trim().toLowerCase(),sup=isSuper();
  const list=ACC.filter(a=>(accRole==="all"||a.role===accRole)&&(!q||a.name.toLowerCase().includes(q)||a.phone.includes(q)));
  if(!list.length)return `<div class="empty">No accounts match.</div>`;
  return `<div class="tblw"><table class="tbl"><tr><th>Name</th><th>Type</th><th>Mobile</th><th>Bookings</th><th>Status</th><th>Actions</th></tr>${list.map(a=>{
    const n=a.role==="pro"?B.filter(b=>b.proId==="p_"+a.id).length:B.filter(b=>b.uid===a.id).length,p=a.role==="pro"?load("fixnear.pro."+a.id,null):null;
    return `<tr><td><b>${esc(a.name)}</b><div class="meta">Joined ${esc(fmtDT(a.created))}</div></td><td>${a.role==="pro"?"Handyman":"Customer"}${p?`<div class="meta">${esc(p.trade)}</div>`:""}</td><td>+91 ${esc(a.phone)}</td><td>${n}</td>
    <td><span class="tag ${a.suspended?"bad":"ok"}">${a.suspended?"Suspended":"Active"}</span></td>
    <td><div class="acts"><button class="btn ghost sm" data-adm="asus" data-id="${a.id}">${a.suspended?"Activate":"Suspend"}</button><button class="btn ghost sm" data-adm="apw" data-id="${a.id}">Reset password</button>${sup?`<button class="btn bad sm" data-adm="adel" data-id="${a.id}">Delete</button>`:""}</div></td></tr>`}).join("")}</table></div>`;
}
function admAccounts(){
  return `<div class="admform" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px"><div style="flex:1;min-width:200px"><input id="accQ" placeholder="Search by name or mobile" value="${esc(accQ)}" aria-label="Search accounts"></div>
  <div style="width:180px"><select id="accRole" aria-label="Account type"><option value="all">All accounts</option><option value="user" ${accRole==="user"?"selected":""}>Customers</option><option value="pro" ${accRole==="pro"?"selected":""}>Handymen</option></select></div></div>
  <div id="accTbl">${accTable()}</div>`;
}
function bkTable(){
  const l=B.filter(b=>bkSt==="all"||(bkSt==="open"?active(b):b.status===bkSt));
  if(!l.length)return `<div class="empty">No bookings in this view.</div>`;
  return `<div class="tblw"><table class="tbl">${BKHEAD.replace("</tr>","<th>Action</th></tr>")}${l.map(b=>bkRow(b).replace(/<\/tr>$/,`<td>${active(b)?`<button class="btn bad sm" data-adm="bcancel" data-id="${esc(b.id)}">Cancel</button>`:""}</td></tr>`)).join("")}</table></div>`;
}
function admBookings(){
  return `<div class="admform" style="width:220px;margin-bottom:12px"><select id="bkSt" aria-label="Booking status">${[["all","All bookings"],["open","Open"],["completed","Completed"],["cancelled","Cancelled"],["declined","Declined"]].map(([v,l])=>`<option value="${v}" ${bkSt===v?"selected":""}>${l}</option>`).join("")}</select></div><div id="bkTbl">${bkTable()}</div>`;
}
function admMaterials(){
  const gs=[...new Set(MATERIALS.map(m=>m.g))];
  return `<p class="lead">Base prices in ₹ for Bengaluru. Other cities are scaled automatically. Customers and handymen see updates straight away.</p>
  <form data-form="mats" class="admform">${gs.map(g=>`<h2 style="margin:16px 0 8px">${esc(g)}</h2><div class="admgrid">${MATERIALS.map((m,i)=>m.g!==g?"":`<div class="panel"><label for="mp${i}" style="margin-top:0">${esc(m.name)}</label><input id="mp${i}" type="number" min="0" step="1" data-mat="${i}" value="${m.p}"><div class="meta">Default ${money(m.base)}</div></div>`).join("")}</div>`).join("")}
  <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap"><button class="btn" type="submit">Save prices</button><button class="btn ghost" type="button" data-adm="matreset">Restore defaults</button></div></form>`;
}
function admSettings(){
  return `<form class="panel admform" data-form="settings" style="margin-bottom:18px"><h2>App settings</h2>
  <div class="row2"><div><label for="stName">App name</label><input id="stName" name="siteName" value="${esc(SITE_NAME)}" maxlength="30"></div>
  <div><label for="stFee">Quick-visit extra fee (₹)</label><input id="stFee" name="quickFee" type="number" min="0" step="10" value="${QUICK_FEE}"></div></div>
  <label for="stAnn">Announcement banner (shown to customers and handymen)</label><textarea id="stAnn" name="announcement" rows="2" maxlength="240" placeholder="Leave empty for no banner">${esc(CFG.announcement||"")}</textarea>
  <label style="display:flex;gap:10px;align-items:center;margin-top:14px"><input type="checkbox" name="showSamples" style="width:auto" ${CFG.showSamples===false?"":"checked"}> Show demo (“Sample”) handymen to customers</label>
  <label style="display:flex;gap:10px;align-items:center;margin-top:10px"><input type="checkbox" name="maintenance" style="width:auto" ${CFG.maintenance?"checked":""}> Maintenance mode (customers and handymen cannot sign in; admins still can)</label>
  <button class="btn" type="submit" style="margin-top:14px">Save settings</button></form>
  <div class="panel admform" style="margin-bottom:18px"><h2>Trades offered</h2><p class="meta" style="margin:4px 0 10px">These appear as filters for customers and in handyman sign-up.</p>
  <div class="chips" style="margin:0 0 12px">${CATEGORIES.map(c=>`<span class="chip" style="display:inline-flex;gap:8px;align-items:center">${esc(c)}<button type="button" data-adm="tdel" data-c="${esc(c)}" aria-label="Remove ${esc(c)}" style="border:0;background:none;cursor:pointer;color:var(--bad);font-weight:700">×</button></span>`).join("")}</div>
  <form data-form="trade" style="display:flex;gap:10px"><input name="t" placeholder="New trade, e.g. Gardener" maxlength="24" aria-label="New trade"><button class="btn" type="submit" style="white-space:nowrap">Add trade</button></form></div>
  <div class="panel"><h2>Backup</h2><p class="meta" style="margin:4px 0 10px">Download accounts (without passwords), bookings and settings as a JSON file.</p><button class="btn ghost" data-adm="backup">Download backup</button></div>`;
}

/* ---------- admin: actions ---------- */
$("admBody").addEventListener("input",e=>{if(e.target.id==="accQ"){accQ=e.target.value;$("accTbl").innerHTML=accTable()}});
$("admBody").addEventListener("change",e=>{
  if(e.target.id==="accRole"){accRole=e.target.value;$("accTbl").innerHTML=accTable()}
  if(e.target.id==="bkSt"){bkSt=e.target.value;$("bkTbl").innerHTML=bkTable()}
});
const needSuper=()=>{if(isSuper())return true;toast("Only administrators can do this.");return false};
$("admBody").addEventListener("click",async e=>{
  const b=e.target.closest("[data-adm]");if(!b||role!=="admin"||!meAdm())return;
  const k=b.dataset.adm,id=b.dataset.id,a=ADM.find(x=>x.id===id),ac=ACC.find(x=>x.id===id);
  if(["mine","reset","toggle","del","tdel","backup"].includes(k)&&!needSuper())return;
  if(k==="mine")return changeOwn(false);
  if(k==="reset"&&a){const c=norm(genCode()),h=await hashSecret(c);Object.assign(a,h,{active:true,mustChange:false});saveADM();renderAdmin();
    return dlgBox({title:"New code for "+a.label,msg:"The old code stops working now. Share this one privately. It is shown only once.",secret:fmtCode(c),ok:"Done",cancel:false})}
  if(k==="toggle"&&a){
    if(a.active&&a.level==="super"&&!superLeft(a.id))return toast("Keep at least one active admin code.");
    a.active=!a.active;saveADM();toast(a.active?"Code restored":"Code revoked");if(!a.active&&a.id===SID)return logout();return renderAdmin()}
  if(k==="del"&&a){
    if(a.level==="super"&&live(a)&&!superLeft(a.id))return toast("Keep at least one active admin code.");
    const ok=await dlgBox({title:"Delete this access code?",msg:`${a.label} will lose access immediately. This can’t be undone.`,ok:"Delete"});if(!ok)return;
    ADM=ADM.filter(x=>x.id!==a.id);saveADM();toast("Code deleted");if(a.id===SID)return logout();return renderAdmin()}
  if(k==="asus"&&ac){ac.suspended=!ac.suspended;saveACC();toast(ac.suspended?"Account suspended":"Account activated");$("accTbl").innerHTML=accTable();return}
  if(k==="apw"&&ac){const ok=await dlgBox({title:"Reset password?",msg:`Create a temporary password for ${ac.name}. Their old password stops working.`,ok:"Reset"});if(!ok)return;
    const p=genPass(),h=await hashSecret(p);Object.assign(ac,h);saveACC();
    return dlgBox({title:"Temporary password",msg:`Give this to ${ac.name} privately. It is shown only once. They can sign in with it.`,secret:p,ok:"Done",cancel:false})}
  if(k==="adel"&&ac){if(!needSuper())return;const ok=await dlgBox({title:"Delete this account?",msg:`${ac.name}’s login and saved profile will be removed. Their past bookings stay in the records.`,ok:"Delete"});if(!ok)return;
    ACC=ACC.filter(x=>x.id!==ac.id);saveACC();localStorage.removeItem("fixnear.pro."+ac.id);localStorage.removeItem("fixnear.cust."+ac.id);toast("Account deleted");return renderAdmin()}
  if(k==="bcancel"){const x=B.find(y=>y.id===id);if(!x)return;const ok=await dlgBox({title:"Cancel this booking?",msg:"Both the customer and the handyman will see it as cancelled by admin.",ok:"Cancel booking"});if(!ok)return;
    x.status="cancelled";x.by="admin";x.why="Cancelled by admin";saveB();toast("Booking cancelled");$("bkTbl").innerHTML=bkTable();return}
  if(k==="matreset"){CFG.matPrices={};saveCFG();applyCfg();renderAdmin();return toast("Default prices restored")}
  if(k==="tdel"){if(CATEGORIES.length<=1)return toast("Keep at least one trade.");CATEGORIES=CATEGORIES.filter(c=>c!==b.dataset.c);CFG.categories=CATEGORIES.slice();saveCFG();if(!CATEGORIES.includes(cat))cat=CATEGORIES[0];return renderAdmin()}
  if(k==="backup"){
    const data={exported:new Date().toISOString(),accounts:ACC.map(({salt,hash,...r})=>r),bookings:B.map(({photo,otp,...r})=>r),settings:CFG};
    const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"})),l=document.createElement("a");
    l.href=u;l.download="nearo-backup-"+new Date().toISOString().slice(0,10)+".json";document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);return}
});
$("admBody").addEventListener("submit",async e=>{
  e.preventDefault();const f=e.target,k=f.dataset.form;if(role!=="admin"||!meAdm())return;
  if((k==="newcode"||k==="settings"||k==="trade")&&!needSuper())return;
  if(k==="newcode"){
    const label=f.label.value.trim(),level=f.level.value,days=+f.exp.value,custom=norm(f.custom.value);
    if(label.length<2)return toast("Enter the person’s name or role.");
    if(custom&&custom.length<8)return toast("A custom code needs at least 8 letters or digits.");
    const code=custom||norm(genCode());if(await codeTaken(code))return toast("That code is already in use. Try another.");
    const h=await hashSecret(code);
    ADM.push({id:newId("a"),label,level,...h,active:true,created:Date.now(),by:meAdm().label,lastUsed:0,expires:days?Date.now()+days*864e5:null});saveADM();renderAdmin();
    return dlgBox({title:"Access code created",msg:`Give this code to ${label}. It is shown only once and can’t be recovered later.`,secret:fmtCode(code),ok:"Done",cancel:false});
  }
  if(k==="mats"){
    CFG.matPrices={};f.querySelectorAll("[data-mat]").forEach(i=>{const m=MATERIALS[+i.dataset.mat],v=Number(i.value);if(i.value!==""&&v>=0&&v!==m.base)CFG.matPrices[m.name]=v});
    saveCFG();applyCfg();renderAdmin();return toast("Material prices saved");
  }
  if(k==="settings"){
    const nm=f.siteName.value.trim(),fee=Number(f.quickFee.value);
    if(!nm)return toast("The app name can’t be empty.");if(!(fee>=0))return toast("Enter a valid quick-visit fee.");
    Object.assign(CFG,{siteName:nm,quickFee:fee,announcement:f.announcement.value.trim(),showSamples:f.showSamples.checked,maintenance:f.maintenance.checked});
    saveCFG();applyCfg();$("siteName").textContent=SITE_NAME;renderAdmin();return toast("Settings saved");
  }
  if(k==="trade"){
    const t=f.t.value.trim().replace(/\s+/g," ");if(!t)return;if(CATEGORIES.some(c=>c.toLowerCase()===t.toLowerCase()))return toast("That trade already exists.");
    CATEGORIES=[...CATEGORIES,t];CFG.categories=CATEGORIES.slice();saveCFG();renderAdmin();return;
  }
});

