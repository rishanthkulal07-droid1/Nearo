/* Nearo - js/start.js
   START-UP: runs last and opens the app.
   Load order in index.html: config, i18n, app, admin, studio, start. */
/* ---------- start ---------- */
async function boot(){
  if(!ADM.length){const h=await hashSecret(DEFAULT_ADMIN_CODE);ADM.push({id:"a_owner",label:"Owner",level:"super",...h,active:true,created:Date.now(),by:"System",lastUsed:0,expires:null,mustChange:true});saveADM()}
  $("siteName").textContent=SITE_NAME;applyTr();applyCustom();runCustomJS();setAuth();showApp();applyLang();
}
boot();

