/* Nearo - js/studio.js
   CODE STUDIO: lets admins change the app with HTML, CSS and JavaScript from inside the app.
   Load order in index.html: config, i18n, app, admin, studio, start. */
const SRC_FILES=["index.html","css/styles.css","js/loader.js","js/config.js","js/i18n.js","js/app.js","js/admin.js","js/studio.js","js/ide.js","js/start.js","js/pwa.js"];
/* ===== CODE STUDIO: lets admins change the app with HTML, CSS and JavaScript ===== */
const SAFE=/[?&]safe=1/.test(location.search);
const SLOTS={login:"Sign-in page (under the form)",top:"Top of every page (after sign-in)",bottom:"Bottom of every page (after sign-in)",footer:"Footer"};
const EXAMPLES={
  css:["/* Custom CSS: applies to the whole app instantly. */","/* Change colours with variables: */",":root{","  --accent:#ff7a59;","}","","/* Rounder cards: */",".card{border-radius:20px}",""].join("\n"),
  js:["// Custom JavaScript: runs when the app starts.","// \"app\" is your doorway into the app. Example: add a Help tab.","app.addTab({","  id: \"help\",","  label: \"Help\",","  roles: [\"user\", \"pro\"],","  html: function () {","    return '<h1>Help centre</h1><p class=\"lead\">Call us on 080 0000 0000, Mon to Sat.</p>';","  }","});","","app.on(\"login\", function (role) {","  if (role === \"user\") app.toast(\"Welcome back!\");","});",""].join("\n"),
  html:'<div class="panel" style="margin:14px 0;text-align:center"><b>Festival offer:</b> 10% off cleaning this week.</div>'
};
const API_REF=['app.addTab({ id, label, roles:["user","pro","admin"], html: "text" or function, onShow(el) })','   adds a new tab with your own page. Runs after login for those roles.','app.on("render" | "login" | "logout", function)   run code when something happens','app.toast("text")      show a small message','app.render()           redraw the current page','app.esc(text)  app.money(1500)   safe text / format rupees','app.role               "user", "pro" or "admin"','app.user               { id, name, phone } of the person signed in','app.bookings           list of all bookings','app.accounts          list of accounts (never includes passwords)','app.config             app settings   |   app.saveConfig() saves and applies them','app.store.get(key, fallback)  /  app.store.set(key, value)   keep your own data','app.log(...)           print to the Terminal'].join("\n");
let CODE=load("nearo.code",{});
CODE.css=CODE.css||{src:"",on:true,hist:[]};CODE.js=CODE.js||{src:"",on:true,hist:[]};CODE.html=CODE.html||{};
const saveCODE=()=>store("nearo.code",CODE);
const ent=(k,s)=>{if(k==="html")return CODE.html[s]||(CODE.html[s]={src:"",on:true,hist:[]});return CODE[k]};
const CODE_ERR=[],CTABS=[],HOOKS={};
const codeErr=(w,err)=>{CODE_ERR.push(new Date().toLocaleTimeString()+"  "+w+": "+((err&&err.message)||err));try{console.error(err)}catch(e){}};
window.addEventListener("error",e=>codeErr("Runtime",e.error||e.message));
window.addEventListener("unhandledrejection",e=>codeErr("Promise",e.reason));
const emit=(ev,...a)=>(HOOKS[ev]||[]).forEach(f=>{try{f(...a)}catch(err){codeErr("Hook "+ev,err)}});
const TLOG=[],THIST=[];let thIdx=-1;
const tprint=(t,c)=>{TLOG.push({t:String(t),c:c||""});if(TLOG.length>300)TLOG.shift()};
const APP={
  esc,money,toast,
  get role(){return role},
  get user(){const a=role==="admin"?meAdm():ACC.find(x=>x.id===SID);return a?{id:a.id,name:a.name||a.label,phone:a.phone||""}:null},
  get config(){return CFG},saveConfig(){saveCFG();applyCfg();$("siteName").textContent=SITE_NAME;render()},
  get bookings(){return B},get accounts(){return ACC.map(({salt,hash,...r})=>r)},
  render:()=>render(),
  on(ev,fn){(HOOKS[ev]=HOOKS[ev]||[]).push(fn)},
  addTab(t){if(!t||!/^[\w-]+$/.test(t.id||"")||!t.label)throw new Error("addTab needs an id (letters, digits, - or _) and a label");CTABS.push(t)},
  store:{get:(k,d)=>load("custom."+k,d),set:(k,v)=>store("custom."+k,v)},
  log:(...a)=>{tprint(a.map(fmtVal).join(" "))}
};
function tabsFor(){const b=tabsBase();if(role===null||(role==="pro"&&!myPro))return b;return b.concat(CTABS.filter(t=>!t.roles||t.roles.includes(role)).map(t=>["x:"+t.id,t.label,0]))}
function renderCustom(key){
  const t=CTABS.find(x=>"x:"+x.id===key),el=$("vCustom");if(!t){el.innerHTML="";return}
  try{el.innerHTML=typeof t.html==="function"?t.html():(t.html||"");if(t.onShow)t.onShow(el)}catch(err){codeErr("Tab "+t.id,err);el.innerHTML='<div class="empty">This tab has an error. Admins: check the Terminal (type errors).</div>'}
}
function applyCustom(){
  let st=$("customCss");if(!st){st=document.createElement("style");st.id="customCss";document.head.appendChild(st)}
  st.textContent=(!SAFE&&CODE.css.on)?CODE.css.src:"";
  document.querySelectorAll("[data-slot]").forEach(el=>{const e=CODE.html[el.dataset.slot];el.innerHTML=(!SAFE&&e&&e.on&&e.src)?e.src:""});
  const any=CODE.css.src.trim()||CODE.js.src.trim()||Object.values(CODE.html).some(e=>e.src.trim());
  $("safeLink").hidden=SAFE||!any;$("safeNote").hidden=!SAFE;
}
function runCustomJS(){
  if(SAFE||!CODE.js.on||!CODE.js.src.trim())return;
  try{new Function("app",CODE.js.src)(APP)}catch(err){codeErr("Custom JavaScript",err)}
}
const TRO={};
function applyTr(){
  const tr=CFG.tr||{};
  Object.keys(TRO).forEach(k=>{if(!(k in tr)){if(TRO[k]===undefined)delete D[k];else D[k]=TRO[k];delete TRO[k]}});
  Object.entries(tr).forEach(([k,v])=>{if(!Array.isArray(v))return;if(!(k in TRO))TRO[k]=D[k];D[k]=v});
}
const fmtVal=v=>{if(typeof v==="string")return v;if(typeof v==="function")return String(v);try{return JSON.stringify(v,null,2)}catch(e){return String(v)}};

/* ---------- the Code studio tab ---------- */
let csTab="ide",csSlot="top",SRC_TEXT=null;
function admStudio(){
  const tabs=[["ide","Source files"],["css","CSS"],["js","JavaScript"],["html","HTML"],["json","Settings (JSON)"],["tr","Translations"],["term","Terminal"],["src","App source"]];
  const safe=SAFE?`<div class="warnbox"><b>Safe mode is on.</b> Your custom CSS, HTML and JavaScript are switched off for this visit, so you can fix a mistake. <a href="./">Exit safe mode</a></div>`:"";
  return `${safe}<p class="lead">Change how the app looks and works using code. Everything here applies to the main app for people using this browser.</p>
  <div class="chips cschips" style="margin:0 0 14px">${tabs.map(([k,l])=>`<button class="chip" data-cs="tab" data-k="${k}" aria-pressed="${csTab===k}">${l}</button>`).join("")}</div>
  ${({ide:csIde,css:csEditor,js:csEditor,html:csEditor,json:csJson,tr:csTr,term:csTerm,src:csSrc})[csTab]()}`;
}
function csEditor(){
  const k=csTab,e=ent(k,csSlot),title={css:"Custom CSS",js:"Custom JavaScript",html:"Custom HTML"}[k];
  const hint={css:"Styles for the whole app. Applies the moment you save.",js:"Runs when the app starts. After you save, the page reloads. Use the app object (reference below).",html:"Blocks of HTML placed in a part of the page. Applies the moment you save."}[k];
  const slot=k==="html"?`<label for="csSlot">Where should it appear?</label><select id="csSlot">${Object.entries(SLOTS).map(([v,l])=>`<option value="${v}" ${v===csSlot?"selected":""}>${l}</option>`).join("")}</select>`:"";
  const hist=e.hist.length?`<select id="csHist" aria-label="Restore an earlier version" style="width:auto"><option value="">Earlier versions…</option>${e.hist.map((h,i)=>`<option value="${i}">${esc(fmtDT(h.t))} · ${h.src.length} characters</option>`).join("")}</select>`:"";
  return `<div class="panel admform"><h2>${title}</h2><p class="meta" style="margin:4px 0 0">${hint}</p>${slot}
  <label for="csEd">Code</label><textarea id="csEd" class="code" rows="16" spellcheck="false" placeholder="Nothing here yet. Press “Insert example” to start.">${esc(e.src)}</textarea>
  <label style="display:flex;gap:8px;align-items:center;font-weight:600"><input type="checkbox" id="csOn" style="width:auto" ${e.on?"checked":""}> Enabled</label>
  <p class="err" id="csErr" role="alert"></p>
  <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center"><button class="btn" data-cs="save">${k==="js"?"Save and reload app":"Save and apply"}</button><button class="btn ghost" data-cs="example">Insert example</button>${hist}</div>
  <p class="meta" style="margin:10px 0 0">Tip: Tab key indents, Ctrl+S saves. If a change breaks the app, open the site with <b>?safe=1</b> at the end of the address.</p></div>
  ${k==="js"?`<details class="panel" style="margin-top:14px"><summary style="cursor:pointer;font-weight:700">app reference: what your JavaScript can use</summary><pre class="code" style="margin-top:10px">${esc(API_REF)}</pre></details>`:""}`;
}
function csJson(){
  return `<div class="panel admform"><h2>Settings (JSON)</h2><p class="meta" style="margin:4px 0 0">App name, quick-visit fee, trades, banner, material prices and translations, as data. Edit and apply.</p>
  <label for="csEd">JSON</label><textarea id="csEd" class="code" rows="14" spellcheck="false">${esc(JSON.stringify(CFG,null,2))}</textarea>
  <p class="err" id="csErr" role="alert"></p><button class="btn" data-cs="savejson">Apply settings</button></div>
  <div class="panel" style="margin-top:14px"><h2>Move your changes to another device</h2><p class="meta" style="margin:4px 0 10px">Export settings, translations and all your code as one file, and import it in another browser or after a reset.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn ghost" data-cs="export">Export everything</button><label class="btn ghost" style="cursor:pointer">Import file<input type="file" id="csImp" accept=".json,application/json" hidden></label></div></div>`;
}
function csTr(){
  const tr=CFG.tr||{},rows=Object.entries(tr).map(([k,v])=>`<tr><td>${esc(k)}</td><td>${esc(v[0])}</td><td>${esc(v[1])}</td><td><div class="acts"><button class="btn ghost sm" data-cs="trpick" data-k="${esc(k)}">Edit</button><button class="btn bad sm" data-cs="trdel" data-k="${esc(k)}">Remove</button></div></td></tr>`).join("");
  return `<div class="panel admform"><h2>Translations (ಕನ್ನಡ and हिन्दी)</h2><p class="meta" style="margin:4px 0 0">Change how any text reads in Kannada or Hindi, or translate text you added with code. The English text must match what is on screen exactly.</p>
  <label for="trQ">Find existing text</label><input id="trQ" placeholder="Type a few words, e.g. Book now" autocomplete="off"><div id="trRes" style="margin:8px 0"></div>
  <form data-form="tr" novalidate><label for="trEn">English text</label><input id="trEn" name="en">
  <div class="row2"><div><label for="trKn">ಕನ್ನಡ</label><input id="trKn" name="kn"></div><div><label for="trHi">हिन्दी</label><input id="trHi" name="hi"></div></div>
  <button class="btn" type="submit" style="margin-top:14px">Save translation</button></form></div>
  <h2 style="margin:20px 0 10px">Your translations</h2>${rows?`<div class="tblw"><table class="tbl"><tr><th>English</th><th>ಕನ್ನಡ</th><th>हिन्दी</th><th></th></tr>${rows}</table></div>`:`<div class="empty">No custom translations yet.</div>`}`;
}
const HELP=["Commands","  help                 show this list","  clear                clear the screen","  whoami               who is signed in","  config               show app settings (JSON)","  set <key> <value>    change a setting, e.g.  set quickFee 200","  unset <key>          remove a setting (back to default)","  accounts             list customer and handyman accounts","  bookings             list bookings","  codes                list access codes (never the codes themselves)","  errors               errors from your custom code","  open <tab>           overview, codes, accounts, bookings, materials, settings, studio","  safe on | off        reload with custom code off / on","  reload               reload the app","","Anything else runs as JavaScript, with  app  available. Try:","  app.toast(\"Hello\")","  app.bookings.length"].join("\n");
function csTerm(){return `<div class="panel"><h2>Terminal</h2><p class="meta" style="margin:4px 0 10px">Type <b>help</b> for commands. Anything else runs as JavaScript.</p><div class="term" id="termOut" role="log" aria-live="polite" tabindex="0"></div><div class="termin"><span aria-hidden="true">$</span><input id="termIn" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Terminal command"></div></div>`}
function termRender(){const o=$("termOut");if(!o)return;o.innerHTML=TLOG.map(l=>`<div class="${l.c}">${esc(l.t)}</div>`).join("");o.scrollTop=o.scrollHeight}
function csSrc(){return `<div class="panel"><h2>App source</h2><p class="meta" style="margin:4px 0 10px">The original code of this app (index.html, css/styles.css and the js/ files), read-only. Download it to change the core in your own editor, then upload the files to your host again. For changes that apply right here, use the CSS, JavaScript and HTML tabs.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px"><button class="btn ghost" data-cs="srcdl">Download all source</button><button class="btn ghost" data-cs="srccopy">Copy all</button></div>
  <textarea id="csSrcTx" class="code" rows="20" readonly spellcheck="false">Loading…</textarea></div>`}
async function csAfter(){
  if(admTab==="studio"&&csTab==="ide"){ideAfter();return}
  if(admTab!=="studio")return;
  if(csTab==="term"){termRender();if(!TLOG.length){tprint("Nearo terminal. Type help for commands.","cmd");termRender()}}
  if(csTab==="src"){
    const tx=$("csSrcTx");if(!tx)return;
    if(SRC_TEXT===null){try{let all="";for(const f of SRC_FILES){const r=await fetch(f,{cache:"no-store"});if(!r.ok)throw 0;all+=(f.endsWith(".html")?"<!-- ===== FILE: "+f+" ===== -->\n":"/* ===== FILE: "+f+" ===== */\n")+await r.text()+"\n\n"}SRC_TEXT=all}catch(e){SRC_TEXT=""}}
    if($("csSrcTx"))$("csSrcTx").value=SRC_TEXT||"Could not load the original file here. Open the hosted site (not a local copy) to view the source.";
  }
}
function csSave(){
  const k=csTab,e=ent(k,csSlot),src=$("csEd").value,E=$("csErr");
  if(k==="js"){try{new Function("app",src)}catch(err){E.textContent="JavaScript error: "+err.message;return}}
  if(e.src!==src&&e.src.trim()){e.hist.unshift({t:Date.now(),src:e.src});e.hist=e.hist.slice(0,10)}
  e.src=src;e.on=$("csOn").checked;saveCODE();
  if(k==="js"){sessionStorage.setItem("nearo.cs","js");toast("Saved. Reloading the app…");setTimeout(()=>location.reload(),700);return}
  applyCustom();toast("Saved and applied");renderAdmin();
}
function csTrFill(en,kn,hi){$("trEn").value=en;$("trKn").value=kn||"";$("trHi").value=hi||"";$("trEn").focus()}
async function termRun(line){
  line=line.trim();if(!line)return;
  tprint("$ "+line,"cmd");THIST.unshift(line);thIdx=-1;
  const c=line.split(/\s+/)[0],arg=line.slice(c.length).trim();
  try{
    if(c==="help")tprint(HELP);
    else if(c==="clear")TLOG.length=0;
    else if(c==="whoami"){const u=APP.user;tprint(u?`${u.name} (${role==="admin"?(meAdm().level==="super"?"admin":"employee"):role})`:"nobody")}
    else if(c==="config")tprint(JSON.stringify(CFG,null,2));
    else if(c==="set"){const m=arg.match(/^(\S+)\s+([\s\S]+)$/);if(!m)tprint("Usage: set <key> <value>","err");else{let v=m[2];try{v=JSON.parse(v)}catch(e){}CFG[m[1]]=v;saveCFG();applyCfg();applyTr();$("siteName").textContent=SITE_NAME;render();tprint(`${m[1]} = ${JSON.stringify(v)}`)}}
    else if(c==="unset"){if(!arg)tprint("Usage: unset <key>","err");else{delete CFG[arg];saveCFG();applyCfg();applyTr();$("siteName").textContent=SITE_NAME;render();tprint(arg+" removed")}}
    else if(c==="accounts")tprint(ACC.length?ACC.map(a=>`${a.role==="pro"?"handyman":"customer"}  ${a.phone}  ${a.name}${a.suspended?"  [suspended]":""}`).join("\n"):"No accounts yet.");
    else if(c==="bookings")tprint(B.length?B.map(b=>`${String(b.id).slice(-6)}  ${b.status}  ${b.name||""} -> ${b.proName||""}  ${money(jobAmount(b))}`).join("\n"):"No bookings yet.");
    else if(c==="codes")tprint(ADM.map(a=>`${a.label}  ${a.level==="super"?"admin":"employee"}  ${!a.active?"revoked":expired(a)?"expired":"active"}`).join("\n"));
    else if(c==="errors")tprint(CODE_ERR.length?CODE_ERR.join("\n"):"No errors.");
    else if(c==="open"){const t=ADM_TABS.map(x=>x[0]);if(t.includes(arg)){admTab=arg;render();tprint("Opened "+arg);return}tprint("Tabs: "+t.join(", "),"err")}
    else if(c==="safe"){if(arg==="on")location.search="?safe=1";else if(arg==="off")location.href=location.pathname;else tprint("Usage: safe on | safe off","err")}
    else if(c==="reload")location.reload();
    else await evalJS(line);
  }catch(err){tprint("Error: "+(err&&err.message||err),"err")}
  termRender();
}
async function evalJS(src){
  const orig=console.log;console.log=(...a)=>tprint(a.map(fmtVal).join(" "));
  try{let f;try{f=new Function("app","return ("+src+"\n)")}catch(e){f=new Function("app",src)}
    const v=await f(APP);if(v!==undefined)tprint(fmtVal(v))}finally{console.log=orig}
}
const studioOK=()=>role==="admin"&&isSuper();
$("admBody").addEventListener("click",async e=>{
  const b=e.target.closest("[data-cs]");if(!b||!studioOK())return;const k=b.dataset.cs;
  if(k==="tab"){csTab=b.dataset.k;return renderAdmin()}
  if(k==="save")return csSave();
  if(k==="example"){$("csEd").value=EXAMPLES[csTab];return}
  if(k==="savejson"){
    let o;try{o=JSON.parse($("csEd").value);if(!o||typeof o!=="object"||Array.isArray(o))throw new Error("Settings must be an object like { ... }")}catch(err){$("csErr").textContent="JSON error: "+err.message;return}
    Object.keys(CFG).forEach(x=>delete CFG[x]);Object.assign(CFG,o);saveCFG();applyCfg();applyTr();$("siteName").textContent=SITE_NAME;render();toast("Settings applied");return}
  if(k==="export"){
    const u=URL.createObjectURL(new Blob([JSON.stringify({format:"nearo-custom-v1",config:CFG,code:CODE},null,2)],{type:"application/json"})),l=document.createElement("a");
    l.href=u;l.download="nearo-customisations.json";document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);return}
  if(k==="trpick"){const key=b.dataset.k,v=(CFG.tr&&CFG.tr[key])||D[key]||[];csTrFill(key,v[0],v[1]);return}
  if(k==="trdel"){const ok=await dlgBox({title:"Remove this translation?",msg:"The original wording comes back.",ok:"Remove"});if(!ok)return;delete CFG.tr[b.dataset.k];saveCFG();applyTr();applyLang();renderAdmin();return}
  if(k==="srcdl"||k==="srccopy"){
    if(!SRC_TEXT)return toast("The source is not loaded.");
    if(k==="srccopy"){if(navigator.clipboard)navigator.clipboard.writeText(SRC_TEXT).then(()=>toast("Copied"),()=>toast("Select the text and copy it"));return}
    const u=URL.createObjectURL(new Blob([SRC_TEXT],{type:"text/plain"})),l=document.createElement("a");l.href=u;l.download="nearo-source.txt";document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),1500)}
});
$("admBody").addEventListener("change",async e=>{
  if(!studioOK())return;
  if(e.target.id==="csSlot"){csSlot=e.target.value;renderAdmin()}
  if(e.target.id==="csHist"&&e.target.value!==""){const h=ent(csTab,csSlot).hist[+e.target.value];if(h)$("csEd").value=h.src;toast("Loaded. Press Save to keep it.")}
  if(e.target.id==="csImp"){
    const f=e.target.files[0];if(!f)return;
    try{const o=JSON.parse(await f.text());if(o.format!=="nearo-custom-v1")throw new Error("This is not a Nearo customisations file.");
      const ok=await dlgBox({title:"Replace your settings and code?",msg:"Your current settings, translations and custom code will be replaced by the file’s contents.",ok:"Import"});if(!ok)return;
      store("nearo.config",o.config||{});store("nearo.code",o.code||{});sessionStorage.setItem("nearo.cs","json");location.reload()}
    catch(err){toast("Import failed: "+err.message)}
  }
});
$("admBody").addEventListener("input",e=>{
  if(!studioOK()||e.target.id!=="trQ")return;
  const q=e.target.value.trim().toLowerCase(),r=$("trRes");if(q.length<2){r.innerHTML="";return}
  const m=Object.keys(D).filter(k=>k.toLowerCase().includes(q)).slice(0,12);
  r.innerHTML=m.length?m.map(k=>`<button type="button" class="chip" style="margin:0 6px 6px 0;text-align:left" data-cs="trpick" data-k="${esc(k)}">${esc(k.length>60?k.slice(0,60)+"…":k)}</button>`).join(""):`<span class="meta">No existing text matches. You can still type your own English text below.</span>`;
});
$("admBody").addEventListener("keydown",e=>{
  if(!studioOK())return;
  if(e.target.id==="csEd"&&!e.target.readOnly){
    if(e.key==="Tab"){e.preventDefault();const t=e.target,s=t.selectionStart;t.value=t.value.slice(0,s)+"  "+t.value.slice(t.selectionEnd);t.selectionStart=t.selectionEnd=s+2}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();if(csTab==="json")document.querySelector('[data-cs="savejson"]').click();else csSave()}
  }
  if(e.target.id==="termIn"){
    if(e.key==="Enter"){e.preventDefault();const v=e.target.value;e.target.value="";termRun(v)}
    else if(e.key==="ArrowUp"){e.preventDefault();if(thIdx<THIST.length-1){thIdx++;e.target.value=THIST[thIdx]}}
    else if(e.key==="ArrowDown"){e.preventDefault();if(thIdx>0){thIdx--;e.target.value=THIST[thIdx]}else{thIdx=-1;e.target.value=""}}
  }
});
$("admBody").addEventListener("submit",e=>{
  const f=e.target;if(f.dataset.form!=="tr"||!studioOK())return;
  const en=f.en.value.trim(),kn=f.kn.value.trim(),hi=f.hi.value.trim();
  if(!en)return toast("Enter the English text.");if(!kn&&!hi)return toast("Enter a Kannada or Hindi translation.");
  CFG.tr=CFG.tr||{};CFG.tr[en]=[kn||(D[en]&&D[en][0])||en,hi||(D[en]&&D[en][1])||en];saveCFG();applyTr();applyLang();renderAdmin();toast("Translation saved");
});

